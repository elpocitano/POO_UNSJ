import csv
from Clase import ViajeroFrecuente

class Archivo:
    def cargar(self): 
        
        lista_viajeros = []
        with open('viajeros.csv', 'r') as archivo:
            lector_csv = csv.reader(archivo, delimiter=',')
        
            for fila in lector_csv:
                numero_de_viajero = fila[0]
                DNI = fila[1]
                nombre = fila[2]
                apellido = fila[3]
                millas_acomuladas = int(fila[4])
                viajero = ViajeroFrecuente(numero_de_viajero,DNI,nombre,apellido,millas_acomuladas)
                lista_viajeros.append(viajero)
        
        return lista_viajeros
    
    def buscarViajero(self, num_viajero):
        lista_viajeros = self.cargar()
        for viajero in lista_viajeros:
            if viajero._ViajeroFrecuente__numero_de_viajero == num_viajero:
                return viajero
        return None
