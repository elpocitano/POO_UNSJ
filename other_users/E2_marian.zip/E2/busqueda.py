from Clase import ViajeroFrecuente
from archivo import lista_viajeros

class Busqueda:
    def buscarViajero(self,num_viajero):
        for viajero in lista_viajeros:
            if viajero.numero_de_viajero == num_viajero:
                return viajero
            else:
                print('Numero de viajero no encontrado, ingresalo nuevamente')
                
         
        
        