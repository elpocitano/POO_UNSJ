
class ViajeroFrecuente:
    def __init__(self,numero_de_viajero,DNI,nombre,apellido,millas_acomuladas):
        self.__numero_de_viajero = numero_de_viajero
        self.__DNI = DNI
        self.__nombre = nombre
        self.__apellido = apellido
        self.__millas_acomuladas = millas_acomuladas
        
    def cantidadTotaldeMillas(self):
        return (self.__millas_acomuladas)
    
    def acomularMillas(self,millas_recorridas):
        self.__millas_acomuladas += millas_recorridas
        return self.__millas_acomuladas
    
    def canjearMillas(self,millas_a_canjear):
        if millas_a_canjear <= self.__millas_acomuladas:
            self.__millas_acomuladas -= millas_a_canjear
            return self.__millas_acomuladas
        
        else:
            print("No tiene las suficientes millas para canjear.\nRealiza la operacion cuando tengas las millas necesarias para el canje.")
            return self.__millas_acomuladas
        
        