from Clase import ViajeroFrecuente
from menu import Menu
from archivo import Archivo
import csv



if __name__ == '__main__':  
    
   print("Inicializando carga.. \n")
   archi = Archivo()
   archi.cargar()
   
   print("Carga finalizada.\n")
   
   viajero = None
   while not viajero:
      numero_viajero = input('Ingresa el numero de viajero: ')
      viajero = archi.buscarViajero(numero_viajero)
      if not viajero:
          print("Número de viajero no encontrado. Intenta nuevamente.")
   
   menuX = Menu(viajero)
   print("Bienvenido al Menú de opciones para el viajero")
   print("a- Consultar cantidad de millas.")
   print("b- Acumular millas.")
   print("c- Canjear millas.")
   print("d- Salir.")
   opcion = input('\nSu opcion es: ')
   if opcion == 'a':
       menuX.opcion_a()
   elif opcion=='b':
       menuX.opcion_b()
   elif opcion=='c':
       menuX.opcion_c()
   elif opcion=='d':
       print('Nos vemos.')
       
       
   else:
        print("Invalido")
   
        