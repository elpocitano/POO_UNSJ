from Clase import ViajeroFrecuente

class Menu:
    def __init__(self,viajero):
        self.__viajero = viajero
        
    
    def opcion_a(self):
        print(f'Las millas totales del viajero son: {self.viajero.cantidadTotaldeMillas}')